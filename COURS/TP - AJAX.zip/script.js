// == FONCTIONS ==

function htmlEntities(text) {
	r = "";
	for (let i = 0; i < text.length; i++) {
		r += "&#" + text.charCodeAt(i) + ";";
	}
	return r;
}

function formatTime(timestamp) {
	const date = new Date(timestamp * 1000);
	const day = "0" + date.getDate();
	const month = "0" + (date.getMonth() + 1);
	const year = "0" + date.getFullYear();
	const hours = date.getHours();
	const minutes = "0" + date.getMinutes();
	const seconds = "0" + date.getSeconds();
	return "le " + day.substr(-2) + "/" + month.substr(-2) + "/" + year.substr(-2) + "</b> à <b>" + hours + ":" + minutes.substr(-2) + ":" + seconds.substr(-2);
}

function createTouitItem(name, message, timestamp) {
	let touit_element = document.createElement("div");
	touit_element.className = "touit-item";
	touit_element.style = "order: -" + timestamp + ";";
	
	let touit_message = document.createElement("p");
	touit_message.innerHTML = htmlEntities(message);
	
	let touit_name = document.createElement("span");
	touit_name.innerHTML = htmlEntities(name);
	
	touit_element.appendChild(touit_message);
	touit_element.appendChild(touit_name);
	
	return touit_element;
}

// == MAIN ==

const send_form = document.getElementById("send_form");
const send_name = document.getElementById("name");
const send_message = document.getElementById("message");
const touit_container = document.getElementById("touit_container");

let last_timestamp = 0;